from Qrue import BOTLOG, BOTLOG_CHATID, Qrh9
from Qrh9.razan.resources.assistant import *
from ..Config import Config
from ..core.inlinebot import *
