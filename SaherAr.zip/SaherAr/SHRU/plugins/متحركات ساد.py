#edit  ~ @a_w_x_6 for Qrh9 

from telethon import events
from SHRU.utils import admin_cmd
from SHRU import Qrh9
from . import *
 
#جميع الحقوق محفوظة لسـورس الساحر تخـمط تبيـن فشلـك

plugin_category = "extra"
@Qrh9.ar_cmd(
    pattern="س1$",
    command=("س1", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    a_w_x_6 = await reply_id(event)
    if sad:
        Qrh9 = f"**˛ 𝘼𝙇𝙨𝙖𝙝𝙚𝙧 . .**\n"
        Qrh9 += f"✛━━━━━━━━━━━━━✛\n"
        Qrh9 += f"**الـمتحـرڪـة الأولـى **"
        await event.client.send_file(event.chat_id, sad, caption=Qrh9, reply_to=a_w_x_6)

#edit  ~ @a_w_x_6 for Qrh9 
#جميع الحقوق محفوظة لسـورس الساحر تخـمط تبيـن فشلـك

@Qrh9.ar_cmd(
    pattern="س2$",
    command=("س2", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    leo = await reply_id(event)
    if sad2:
        RAZAN = f"**˛ 𝘼𝙇𝙨𝙖𝙝𝙚𝙧 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـثـانيـة **"
        await event.client.send_file(event.chat_id, sad2, caption=RAZAN, reply_to=leo)

#edit  ~ @a_w_x_6 for Qrh9 
#جميع الحقوق محفوظة لسـورس الساحر تخـمط تبيـن فشلـك

@Qrh9.ar_cmd(
    pattern="س3$",
    command=("س3", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    sic_id = await reply_id(event)
    if sad3:
        RAZAN = f"**˛ 𝘼𝙇𝙨𝙖𝙝𝙚𝙧 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـثـالثـة**\n"
        await event.client.send_file(event.chat_id, sad3, caption=RAZAN, reply_to=sic_id)

#edit  ~ @a_w_x_6 for Qrh9 
#جميع الحقوق محفوظة لسـورس الساحر تخـمط تبيـن فشلـك

@Qrh9.ar_cmd(
    pattern="س4$",
    command=("س4", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad4:
        RAZAN = f"** ˛𝘼𝙇𝙨𝙖𝙝𝙚𝙧. .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـرابـعـة**\n"
        await event.client.send_file(
            event.chat_id, sad4, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @a_w_x_6 for Qrh9 
#جميع الحقوق محفوظة لسـورس الساحر تخـمط تبيـن فشلـك

@Qrh9.ar_cmd(
    pattern="س5$",
    command=("س5", plugin_category),
           )

async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad5:
        RAZAN = f"** ˛ 𝘼𝙇𝙨𝙖𝙝𝙚𝙧 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـخامسـة**\n"
        await event.client.send_file(
            event.chat_id, sad5, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @a_w_x_6 for Qrh9 
#جميع الحقوق محفوظة لسـورس الساحر تخـمط تبيـن فشلـك

@Qrh9.ar_cmd(
    pattern="س6$",
    command=("س6", plugin_category),
           )

async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad6:
        RAZAN = f"**˛ 𝘼𝙇𝙨𝙖𝙝𝙚𝙧 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـسادسـة**\n"
        await event.client.send_file(
            event.chat_id, sad6, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @a_w_x_6 for Qrh9 
#جميع الحقوق محفوظة لسـورس الساحر تخـمط تبيـن فشلـك

@Qrh9.ar_cmd(
    pattern="س7$",
    command=("س7", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad7:
        RAZAN = f"**˛ 𝘼𝙇𝙨𝙖𝙝𝙚𝙧 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـسـابعـة**\n"
        await event.client.send_file(
            event.chat_id, sad7, caption=RAZAN, reply_to=reply_to_id
        )
      
      
@Qrh9.ar_cmd(
    pattern="س8$",
    command=("س8", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad8:
        RAZAN = f"** ˛𝘼𝙇𝙨𝙖𝙝𝙚𝙧  . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الثـامنـة**\n"
        await event.client.send_file(
            event.chat_id, sad8, caption=RAZAN, reply_to=reply_to_id
        )

@Qrh9.ar_cmd(
    pattern="س9$",
    command=("س9", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad9:
        RAZAN = f"** ˛ 𝘼𝙇𝙨𝙖𝙝𝙚𝙧 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة التـاسعـة**\n"
        await event.client.send_file(
            event.chat_id, sad9, caption=RAZAN, reply_to=reply_to_id
        )
#edit  ~ @a_w_x_6 for Qrh9 
#جميع الحقوق محفوظة لسـورس الساحر تخـمط تبيـن فشلـك
