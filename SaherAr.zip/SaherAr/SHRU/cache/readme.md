To store cache file of SHRU
