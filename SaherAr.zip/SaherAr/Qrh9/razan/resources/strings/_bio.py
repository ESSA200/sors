# to loaded bio 
# by ~ @a_w_x_2
# For @a_w_x_2


JEP = [
    """
`• 𝑻𝒉𝒆 𝑳𝒐𝒗𝒆𝒓 𝒐𝒇 𝑾𝒉𝒐𝒎 𝑯𝒆 𝑳𝒐𝒗𝒆𝒔 𝒊𝒔 𝑶𝒃𝒆𝒅𝒊𝒆𝒏𝒕 ♡`

`• 𝒆𝒏𝒐𝒖𝒈𝒉 𝒊𝒅𝒆𝒂𝒍, 𝒘𝒓𝒆𝒕𝒄𝒉𝒆𝒅 𝒘𝒐𝒓𝒍𝒅 ၄`

`• 𝑰'𝒎 𝑻𝒉𝒆 𝑶𝒏𝒆 𝑾𝒉𝒐 𝑪𝒓𝒆𝒂𝒕𝒆𝒔 #𝑪𝒉𝒂𝒏𝒄𝒆𝒔 ༒`

`• Smile, no one cares how you feel!`

`• The sweetest thing said in consolation : if I can't light you, I'll turn it off with you.`

➖➖➖➖➖➖➖➖➖➖➖➖➖
 ⌔︙CH : @a_w_x_2
""",
    """
`• Never let someone who has done nothing tell you how to do anything .`

`• The man who drags you into the shadows, to say "I love you", loves another woman.`

`• It happens a lot to miss, not for anyone but for yourself years ago.`

`• 𝒕𝒉𝒆 𝒅𝒂𝒚 𝒘𝒊𝒍𝒍 𝒄𝒐𝒎𝒆 𝒘𝒉𝒆𝒏 𝒚𝒐𝒖 𝒔𝒕𝒂𝒏𝒅 𝒃𝒆𝒓𝒐𝒓𝒆 𝒚𝒐𝒖𝒓 𝒅𝒓𝒆𝒂𝒎,𝒑𝒓𝒐𝒖𝒅 𝒐𝒓 𝒘𝒉𝒂𝒕 𝒚𝒐𝒖 𝒉𝒂𝒗𝒆 𝒑𝒓𝒐𝒗𝒊𝒅𝒆𝒅,𝒂𝒏𝒅 𝒊𝒓 𝒚𝒐𝒖 𝒂𝒓𝒆 𝒕𝒊𝒓𝒆𝒅 𝒓𝒐𝒓 𝒊𝒕,𝒚𝒐𝒖 𝒘𝒊𝒍𝒍 𝒓𝒊𝒏𝒅 𝒊𝒕 𝒊𝒏 𝒓𝒓𝒐𝒏𝒕 𝒐𝒓 𝒚𝒐𝒖.`

`• Who hates you won't hurt you !Aren't to hurt you only you love.`

➖➖➖➖➖➖➖➖➖➖➖➖➖
 ⌔︙CH : @a_w_x_2
""",
    """
`• Death ends a life. not a relationship ،`

`• Never let someone who has done nothing tell you how to do anything ،`

`• The only power I owned is that I can stop, suddenly about doing something I love .`

`• No one goes beyond and no one goes beyond everything we tone .`

`• This suffering will deliver a beast, will never give birth .`

➖➖➖➖➖➖➖➖➖➖➖➖➖
 ⌔︙CH : @a_w_x_2
""",
    """
`• This suffering will deliver a beast, will never give birth .`

`• Real We are not perfect or extraordinary .`

`• 𝐖𝐇𝐀𝐓 𝐌𝐀𝐊𝐄𝐒 𝐘𝐎𝐔 𝐃𝐈𝐅𝐅𝐄𝐑𝐄𝐍𝐓 ⁞𝐌𝐀𝐊𝐄𝐒 𝐘𝐎𝐔 𝐁𝐄𝐀𝐔𝐓𝐈𝐅𝐔𝐋 ⁽💎🌩₎⇣✿ .`

`• 𝐁𝐄𝐀𝐔𝐓𝐘 𝐈𝐒 𝐖𝐈𝐓𝐇𝐈𝐍 𝐘𝐎𝐔𝐑𝐄 𝐇𝐄𝐀𝐑𝐓 ⚡️🔱 .`

`• 𝐃𝐎𝐍𝐓 𝐆𝐈𝐕𝐄 𝐀𝐍𝐘𝐎𝐍𝐄 𝐎𝐕𝐄𝐑 𝐇𝐈𝐒 𝐕𝐀𝐋𝐔𝐄 😴♩✿⇣.`

➖➖➖➖➖➖➖➖➖➖➖➖➖
 ⌔︙CH : @a_w_x_2
""",
    """
`• Interest will not come you except from someone who wants you .`

`• 𝙜𝙞𝙫𝙚 𝙡𝙤𝙫𝙚 𝙩𝙤 𝙩𝙝𝙤𝙨𝙚 𝙬𝙝𝙤 𝙜𝙞𝙫𝙚 𝙮𝙤𝙪𝙧 𝙙𝙚𝙩𝙖𝙞𝙡𝙨 𝙩𝙝𝙚𝙞𝙧 𝙨𝙖𝙣𝙘𝙩𝙞𝙩𝙮."`

`• I 𝐛𝐮𝐫𝐧𝐞𝐝 𝐚 𝐥𝐨𝐭 𝐚𝐧𝐝 𝐛𝐞𝐜𝐚𝐦𝐞 𝐚 𝐬𝐭𝐚𝐫 .`

`• 𝒔𝒖𝒅𝒅𝒆𝒏𝒍𝒚 𝒆𝒗𝒆𝒓𝒚𝒕𝒉𝒊𝒏𝒈 𝒇𝒂𝒍𝒍𝒔 𝒂𝒑𝒂𝒓𝒕 𝒂𝒕 𝒐𝒏𝒄𝒆.🤍. ★`

`• 𝒅𝒐𝒏 𝒕 𝒄𝒂𝒓𝒆 𝒂𝒃𝒐𝒖𝒕 𝒘𝒉𝒂𝒕 𝒑𝒆𝒐𝒑𝒍𝒆 𝒘𝒂𝒏𝒕 , 𝒄𝒂𝒓𝒆 𝒂𝒃𝒐𝒖𝒕 ، 𝒘𝒉𝒂𝒕 𝒚𝒐𝒖 𝒘𝒂𝒏𝒕 .`

➖➖➖➖➖➖➖➖➖➖➖➖➖
 ⌔︙CH : @a_w_x_2
""",
]

JEPIRQ = [
    """
- ‏ستنتهي الخيوط التي كُنت أجمع بها نفسي سأصبح مُمَزّقً للأبد .
""",
"""
- قلوبنا مليئة برسائل ، لم تكتب .
‏- لاشيء يمضي، نحن نعتاد فقط
- لا يمُكنك جرحه، هو ممزق بالفعل إلى أجزاء.
- مابال قَلبي لم يَعُد يَشعُر؟
""",
"""︎
- ‏كُل شيء يحتاج لعناق ليّعود عامراً بعد الخراب .
- ملامحِيِ بدأت تَتحدث عنّ التعب الّذي أحمله بداخليِ.
- حب الخير للغير جهاد ‏لاتقدر عليه كل النفوس..
- الجرح هو المكان الذي يدخلُ منهُ النّور إليك.
- ‏ينتصر صانِعي البَهجة لأنفسهم، لا مُنتظريها.
""",
"""
- إن الحياة بحد ذاتها مملة، حمقاء، قذرة ، تشدك كالمستنقع
""",
"""
‏- سلاماً على من مرّ على مُرِّنا فحلّاه.
- إستمر وكأن لا شيء يؤذيك
- مات شعور الاستغراب اصبح كل شي متوقع
- يُمهل الله أمانينا ولا يهملُها.🕊️ 💞
- لست أحدا وسأظل هكذا إلى الأبد
- لاتعط أحداً قط الفرصة لإضاعة وقتك مرتين 📓🤎
- مازلت اتمنى الشيء الذي يجعلني ابتسم
- مشاعر مُتراكمة..على حافة الإنفِجار 
- كل الذين ربطو سعادتهم بالآخرين ، ماتوا مقتولين من الوحده 
""",
"""
‏- ستموت قبل أن تسمع الكلمات التي تنتظرها

- لا بأس بالوحده ، ان كان الجميع يؤذي قلبك .!.""",
"""
- لست على ما يرام ولكني أحاول أن ابدو انني بخير.

- جهد كبير في محاربة الأفكار 
- تأقلمت على حزني إلا انه ما زال يبكيني مراراً
"""
]
